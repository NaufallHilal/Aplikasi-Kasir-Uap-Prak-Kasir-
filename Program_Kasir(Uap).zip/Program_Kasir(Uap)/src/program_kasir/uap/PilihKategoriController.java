package program_kasir.uap;

import static db.DBHelper.getConnection;
import java.io.IOException;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Statement;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.stage.Stage;

public class PilihKategoriController {
    @FXML
    private Button btnOk;
    @FXML
    private Button btnKembali;

    @FXML
    private TableColumn<Barang, String> Barcode;

    @FXML
    private TableColumn<Barang,Double> diskon;

    @FXML
    private TableColumn<Barang, String> expired;

    @FXML
    private TextField fieldPilihan;

    @FXML
    private TableColumn<Barang, Double> harga;

    @FXML
    private TableColumn<Barang, Integer> jumlah;

    @FXML
    private TableColumn<Barang, String> kategori;

    @FXML
    private TableColumn<Barang, String> nama;

    @FXML
    private TableView<Barang> tblPilhKategori;

    @FXML
    void initTableBrg(ActionEvent event) {
        Barcode.setCellValueFactory(new PropertyValueFactory<Barang,String>("barcode"));
        nama.setCellValueFactory(new PropertyValueFactory<Barang,String>("nama_produk"));
        harga.setCellValueFactory(new PropertyValueFactory<Barang,Double>("harga"));
        jumlah.setCellValueFactory(new PropertyValueFactory<Barang,Integer>("jumlah"));
        diskon.setCellValueFactory(new PropertyValueFactory<Barang,Double>("diskon"));
        expired.setCellValueFactory(new PropertyValueFactory<Barang,String>("expired"));
        kategori.setCellValueFactory(new PropertyValueFactory<Barang,String>("kategori"));
        tblPilhKategori.setItems(getBarangSelect());
    }
    public ObservableList<Barang> getBarangSelect(){
        ObservableList<Barang> barangList=FXCollections.observableArrayList();
        Connection conn=getConnection();
        String query="SELECT * FROM `barang` WHERE barang.kategori='"+this.fieldPilihan.getText()+"';";
        Statement st;
        ResultSet rs;
        Barang barang;
        Kategori kategori;
        try{
            st=conn.createStatement();
            rs=st.executeQuery(query);
            while(rs.next()){
                barang=new Barang(rs.getString("barcode"),rs.getString("expired"),rs.getString("nama_barang"),rs.getDouble("harga"),rs.getInt("jumlah"),rs.getDouble("diskon"));
                barang.setKategori(rs.getString("kategori"));
                barangList.add(barang);
            }
        }catch(Exception ex){
                ex.printStackTrace();
            }
        return barangList;
        }
    @FXML
    void openMenu(ActionEvent event) throws IOException {
        FXMLLoader loader = new FXMLLoader(getClass().getResource("Menu.fxml"));
        Parent root =loader.load();
        
        Stage stage =(Stage) btnKembali.getScene().getWindow();
        stage.setScene(new Scene(root));
    }
}

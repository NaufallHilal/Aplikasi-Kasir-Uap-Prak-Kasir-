package program_kasir.uap;

import db.DBHelper;
import static db.DBHelper.getConnection;
import java.io.IOException;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.stage.Stage;

public class DataPembelianController {

    @FXML
    private TableColumn<Produk, Double> Diskon;

    @FXML
    private TableColumn<Produk, Double> Harga;

    @FXML
    private TableColumn<Produk, Integer> Jumlah;

    @FXML
    private TableColumn<Produk, String> Nama;

    @FXML
    private Label jmlProduk;

    @FXML
    private Label lblStok;
    
    @FXML
    private Button btnKembali;

    @FXML
    private TableView<Produk> tbProdukPembelian;
    @FXML
    private Button btnTambah;
    @FXML
    private Button btnhapus;
    @FXML
    private TextField fieldDelete;
    
    public void init(){
        ObservableList<Produk> produkList=FXCollections.observableArrayList();
        Connection conn=getConnection();
        String queryBrg="SELECT * FROM barang;";
        String queryMkn="SELECT * FROM makanan;";
        Statement st;
        ResultSet rs,rsMkn;
        Produk produk;
        Penjualan p=new Penjualan(2,12);
        try{
        st=conn.createStatement();
        rs=st.executeQuery(queryBrg);
        while(rs.next()){
            produk=new Produk(rs.getString("nama_barang"),rs.getDouble("harga"),rs.getInt("jumlah"),rs.getDouble("diskon"));
            produkList.add(produk);
            p.setStok(p.getStok()+rs.getInt("jumlah"));
        }
        st=conn.createStatement();
        rsMkn=st.executeQuery(queryMkn);
            while(rsMkn.next()){
                produk=new Produk(rsMkn.getString("nama_makanan"),rsMkn.getDouble("harga"),rsMkn.getInt("jumlah"),rsMkn.getDouble("diskon"));
                produkList.add(produk);
                p.setStok(p.getStok()+rs.getInt("jumlah"));
            }
        } catch (SQLException ex) {
            Logger.getLogger(DataPembelianController.class.getName()).log(Level.SEVERE, null, ex);
        }
        p.setJumlahProduk(produkList.size());
        Diskon.setCellValueFactory(new PropertyValueFactory<Produk,Double>("diskon"));
        Harga.setCellValueFactory(new PropertyValueFactory<Produk,Double>("harga"));
        Jumlah.setCellValueFactory(new PropertyValueFactory<Produk,Integer>("jumlah"));
        Nama.setCellValueFactory(new PropertyValueFactory<Produk,String>("nama_produk"));
        tbProdukPembelian.setItems(produkList);
     
        jmlProduk.setText("Jumlah Produk : "+p.getJumlahProduk());
        lblStok.setText("Stok : "+p.getStok());
    }
    public void initialize(){
        init();
    }
    
    @FXML
    void openMenu(ActionEvent event) throws IOException {
        FXMLLoader loader = new FXMLLoader(getClass().getResource("Menu.fxml"));
        Parent root =loader.load();
        
        Stage stage =(Stage) btnKembali.getScene().getWindow();
        stage.setScene(new Scene(root));
    }

    @FXML
    private void openFormInputBarang(ActionEvent event) throws IOException {
        FXMLLoader loader = new FXMLLoader(getClass().getResource("formInputBarang.fxml"));
        Parent root =loader.load();
        
        Stage stage =(Stage) btnTambah.getScene().getWindow();
        stage.setScene(new Scene(root));
    }

    @FXML
    private void deleteProduk(ActionEvent event) {
        String deleteBrg="DELETE FROM barang WHERE nama_barang='"+fieldDelete.getText()+"';";
            
        try {
            Connection CONN = DBHelper.getConnection();
            if(CONN.createStatement().executeUpdate(deleteBrg)>0){
                System.out.println("Berhasil Menghapus Data");
            }else{
                System.out.println("Gagal Menghapus Data");
            }
        } catch (Exception ex) {
            ex.printStackTrace();
        }finally{
            String deleteMkn="DELETE FROM makanan WHERE nama_makanan='"+fieldDelete.getText()+"';";    
            try {
                Connection CONN = DBHelper.getConnection();
                if(CONN.createStatement().executeUpdate(deleteMkn)>0){
                    System.out.println("Berhasil Menghapus Data");
                }else{
                    System.out.println("Gagal Menghapus Data");
                }
            } catch (Exception ex) {
                ex.printStackTrace();
        }
        }
        
        
    }
}

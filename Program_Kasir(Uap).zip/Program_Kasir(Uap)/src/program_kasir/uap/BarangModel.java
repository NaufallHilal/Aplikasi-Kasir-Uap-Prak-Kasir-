/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package program_kasir.uap;

import db.DBHelper;
import java.sql.Connection;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author Naufal Hilal
 */
public class BarangModel {
    private final Connection CONN;
    public boolean status;

    public BarangModel() {
        this.CONN = DBHelper.getConnection();
    } 
    
    public void addBarang(Barang brg, Kategori k){
        String insert="INSERT INTO barang VALUES ('"
                +brg.getBarcode()+"', '"+brg.getNama_produk()
                +"', '"+brg.getHarga()+"', '"+brg.getJumlah()+"', '"+brg.getDiskon()+"', '"+brg.getExpired()+"', '"+k.getNama_kategori()+"');";
        
        try {
            if(CONN.createStatement().executeUpdate(insert)>0){
                System.out.println("Berhasil Memasukan Data");
                status=true;
            }else{
                System.out.println("Gagal Memasukan Data");
                status=false;
            }
        } catch (SQLException ex) {
            Logger.getLogger(Barang.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    
    public void deleteBarang(String barcode){
        String delete="DELETE FROM barang WHERE barcode='"+barcode+"';";
            
        try {
            if(CONN.createStatement().executeUpdate(delete)>0){
                System.out.println("Berhasil Menghapus Data");
                status=true;
            }else{
                System.out.println("Gagal Menghapus Data");
                status=false;
            }
        } catch (SQLException ex) {
            Logger.getLogger(BarangModel.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    
    public void deleteBarangFromKategori(String kategori){
        String query="DELETE FROM barang WHERE kategori LIKE '%"+kategori+"%';";
        try {
            if(CONN.createStatement().executeUpdate(query)>0){
                System.out.println("Berhasil Menghapus Data");
                status=true;
            }else{
                System.out.println("Gagal Menghapus Data");
                status=false;
            }
        } catch (SQLException ex) {
            Logger.getLogger(BarangModel.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
}

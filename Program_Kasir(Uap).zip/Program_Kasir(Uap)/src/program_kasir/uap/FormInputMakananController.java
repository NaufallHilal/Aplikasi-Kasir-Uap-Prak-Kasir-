package program_kasir.uap;

import java.io.IOException;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.stage.Stage;

public class FormInputMakananController {

    @FXML
    private Button btnAdd;

    @FXML
    private Button btnKembali;

    @FXML
    private TextField fieldDayaTahan;

    @FXML
    private TextField fieldDiskon;

    @FXML
    private TextField fieldHarga;

    @FXML
    private TextField fieldID;

    @FXML
    private TextField fieldJumlah;

    @FXML
    private TextField fieldNama;
    
    @FXML
    private Label lblStatus;

    @FXML
    void openMenu(ActionEvent event) throws IOException {
        FXMLLoader loader = new FXMLLoader(getClass().getResource("Menu.fxml"));
        Parent root =loader.load();
        
        Stage stage =(Stage) btnKembali.getScene().getWindow();
        stage.setScene(new Scene(root));
    }

    @FXML
    void sendDataMakanan(ActionEvent event) {
        Makanan mkn =new Makanan(Integer.parseInt(fieldID.getText()),Integer.parseInt(fieldDayaTahan.getText()),fieldNama.getText(),Double.parseDouble(fieldHarga.getText()),Integer.parseInt(fieldJumlah.getText()),Double.parseDouble(fieldDiskon.getText()));
        
        MakananModel mkn1= new MakananModel();
        mkn1.addMakanan(mkn);
        
        if(mkn1.status==true){
            lblStatus.setText("Berhasil Memasukan Data "+mkn.getNama_produk());
        }else{
            lblStatus.setText("Gagal Memasukan Data");
        }        
        fieldDayaTahan.clear();
        fieldDiskon.clear();
        fieldHarga.clear();
        fieldID.clear();
        fieldJumlah.clear();
        fieldNama.clear();
    }   

}

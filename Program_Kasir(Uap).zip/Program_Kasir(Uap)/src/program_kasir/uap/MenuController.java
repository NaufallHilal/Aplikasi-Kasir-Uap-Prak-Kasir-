package program_kasir.uap;

import static db.DBHelper.getConnection;
import java.io.IOException;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.stage.Stage;

public class MenuController {
    
    @FXML
    private Button barangDelete;
    @FXML
    private Button barangNew;
    @FXML
    private Button makananDelete;

    @FXML
    private Button makananNew;
    
    @FXML
    private Button selectKategori;
     
    @FXML
    private Button btnHapusKategori;
    
    @FXML
    private TableView<Barang> tbBrg;
    
    @FXML
    private Button btnDataPembelian;
   
    @FXML
    private TableView<Makanan> tbMkn;
    @FXML
    private TableColumn<Makanan, Integer> idMkn;
    @FXML
    private TableColumn<Makanan, String> namaMkn;
    @FXML
    private TableColumn<Makanan, Double> hargaMkn;
    @FXML
    private TableColumn<Makanan, Integer> jmlMkn;
    @FXML
    private TableColumn<Makanan, Double> diskonMkn;
    @FXML
    private TableColumn<Makanan, Integer> dayaTahanMkn;
    @FXML
    private TableColumn<Barang, String> barcodeBarang;
    @FXML
    private TableColumn<Barang, String> namaBarang;
    @FXML
    private TableColumn<Barang, Double> hargaBarang;
    @FXML
    private TableColumn<Barang, Integer> jmlBarang;
    @FXML
    private TableColumn<Barang, Double> diskonBarang;
    @FXML
    private TableColumn<Barang, String> expiredBarang;
    @FXML
    private TableColumn<Barang,String> kategoriBarang;

    @FXML
    void openFormInputBarang(ActionEvent event) throws IOException {
        FXMLLoader loader = new FXMLLoader(getClass().getResource("formInputBarang.fxml"));
        Parent root =loader.load();
        
        Stage stage =(Stage) barangNew.getScene().getWindow();
        stage.setScene(new Scene(root));
    }

    @FXML
    void openFormDeleteBarang(ActionEvent event) throws IOException {
        FXMLLoader loader = new FXMLLoader(getClass().getResource("FormDeleteBarang.fxml"));
        Parent root =loader.load();
        
        Stage stage =(Stage) barangDelete.getScene().getWindow();
        stage.setScene(new Scene(root));
    }

    @FXML
    void openFormDeleteMakanan(ActionEvent event) throws IOException {
        FXMLLoader loader = new FXMLLoader(getClass().getResource("FormDeleteMakanan.fxml"));
        Parent root =loader.load();
        
        Stage stage =(Stage) makananDelete.getScene().getWindow();
        stage.setScene(new Scene(root));
    }
     @FXML
    void openFormInputMakanan(ActionEvent event) throws IOException {
        FXMLLoader loader = new FXMLLoader(getClass().getResource("FormInputMakanan.fxml"));
        Parent root =loader.load();
        
        Stage stage =(Stage) makananNew.getScene().getWindow();
        stage.setScene(new Scene(root));
    }
    
    @FXML
    void openPilihFormKategori(ActionEvent event) throws IOException {
        FXMLLoader loader = new FXMLLoader(getClass().getResource("PilihKategori.fxml"));
        Parent root =loader.load();
        
        Stage stage =(Stage) selectKategori.getScene().getWindow();
        stage.setScene(new Scene(root));
    }
    
    @FXML
    void openFormDeleteKategori(ActionEvent event) throws IOException {
        FXMLLoader loader = new FXMLLoader(getClass().getResource("hapusKategori.fxml"));
        Parent root =loader.load();
        
        Stage stage =(Stage) btnHapusKategori.getScene().getWindow();
        stage.setScene(new Scene(root));
    }
    
    @FXML
    void openFormDataPembelian(ActionEvent event) throws IOException {
        FXMLLoader loader = new FXMLLoader(getClass().getResource("DataPembelian.fxml"));
        Parent root =loader.load();
        
        Stage stage =(Stage) btnDataPembelian.getScene().getWindow();
        stage.setScene(new Scene(root));
    }
    
    public void initTableMkn(){
        idMkn.setCellValueFactory(new PropertyValueFactory<Makanan,Integer>("id"));
        namaMkn.setCellValueFactory(new PropertyValueFactory<Makanan,String>("nama_produk"));
        hargaMkn.setCellValueFactory(new PropertyValueFactory<Makanan,Double>("harga"));
        jmlMkn.setCellValueFactory(new PropertyValueFactory<Makanan,Integer>("jumlah"));
        diskonMkn.setCellValueFactory(new PropertyValueFactory<Makanan,Double>("diskon"));
        dayaTahanMkn.setCellValueFactory(new PropertyValueFactory<Makanan,Integer>("daya_tahan"));
        TableViewModel tbv = new TableViewModel();
        tbMkn.setItems(tbv.getMakanan());
    }
    
     public void initTableBrg(){
        barcodeBarang.setCellValueFactory(new PropertyValueFactory<Barang,String>("barcode"));
        namaBarang.setCellValueFactory(new PropertyValueFactory<Barang,String>("nama_produk"));
        hargaBarang.setCellValueFactory(new PropertyValueFactory<Barang,Double>("harga"));
        jmlBarang.setCellValueFactory(new PropertyValueFactory<Barang,Integer>("jumlah"));
        diskonBarang.setCellValueFactory(new PropertyValueFactory<Barang,Double>("diskon"));
        expiredBarang.setCellValueFactory(new PropertyValueFactory<Barang,String>("expired"));
        kategoriBarang.setCellValueFactory(new PropertyValueFactory<Barang,String>("kategori"));
        TableViewModel tbv = new TableViewModel();
        tbBrg.setItems(tbv.getBarang());
    }
    
    @FXML
    public void initialize(){
        initTableMkn();
        initTableBrg();
    }
    
}


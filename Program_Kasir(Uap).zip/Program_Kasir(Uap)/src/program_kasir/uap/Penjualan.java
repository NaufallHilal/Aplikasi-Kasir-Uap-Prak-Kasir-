/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package program_kasir.uap;

import java.util.ArrayList;

/**
 *
 * @author Naufal Hilal
 */
public class Penjualan implements ProductCounter{
    private ArrayList<Produk> listProduk=new ArrayList<>();
    private int jumlahProduk;
    private int stok;
    
    public Penjualan (){
    
    }
    
    public Penjualan(int jumlahProduk, int stok) {
        this.jumlahProduk = jumlahProduk;
        this.stok = stok;
    }

    public ArrayList<Produk> getListProduk() {
        return listProduk;
    }

    public int getJumlahProduk() {
        return jumlahProduk;
    }

    public int getStok() {
        return stok;
    }

    public void setListProduk(ArrayList<Produk> listProduk) {
        this.listProduk = listProduk;
    }

    public void setJumlahProduk(int jumlahProduk) {
        this.jumlahProduk = jumlahProduk;
    }

    public void setStok(int stok) {
        this.stok = stok;
    }
    
    public void getProduk(){
        
    }
   
    @Override
    public void hitungJumlahProduk(){
        
    }
    @Override
    public void hitungHargaProduk(){
        
    }
}

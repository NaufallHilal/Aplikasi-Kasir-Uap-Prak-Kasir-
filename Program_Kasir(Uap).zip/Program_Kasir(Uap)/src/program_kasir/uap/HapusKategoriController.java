package program_kasir.uap;

import java.io.IOException;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.stage.Stage;

public class HapusKategoriController {

    @FXML
    private Button btnDelete;

    @FXML
    private Button btnKembali;

    @FXML
    private TextField fieldKategori;
    
    @FXML
    private Label lblStatus;

    @FXML
    void deleteData(ActionEvent event) {
        BarangModel b=new BarangModel();
        b.deleteBarangFromKategori(fieldKategori.getText());
        
         if(b.status==true){
            lblStatus.setText("Berhasil Menghapus Data "+fieldKategori.getText());
        }else{
            lblStatus.setText("Gagal Menghapus Data");
        }        
        fieldKategori.clear();
    }

    @FXML
    void openMenu(ActionEvent event) throws IOException {
        FXMLLoader loader = new FXMLLoader(getClass().getResource("Menu.fxml"));
        Parent root =loader.load();
        
        Stage stage =(Stage) btnKembali.getScene().getWindow();
        stage.setScene(new Scene(root));
    }

}

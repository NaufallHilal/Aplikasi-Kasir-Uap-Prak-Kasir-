package program_kasir.uap;

import java.io.IOException;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.stage.Stage;

public class FormDeleteBarangController {

    @FXML
    private Button btnDelete;

    @FXML
    private Button btnKembali;
    
    @FXML
    private TextField fieldBarcode;
    
    @FXML
    private Label lblStatus;

    @FXML
    void deleteDataBarang(ActionEvent event) {
        BarangModel b=new BarangModel();
        b.deleteBarang(fieldBarcode.getText());
        
         if(b.status==true){
            lblStatus.setText("Berhasil Menghapus Data "+fieldBarcode.getText());
        }else{
            lblStatus.setText("Gagal Menghapus Data");
        }        
        fieldBarcode.clear();
    }
    @FXML
    void OpenMenu(ActionEvent event) throws IOException {
        FXMLLoader loader = new FXMLLoader(getClass().getResource("Menu.fxml"));
        Parent root =loader.load();
        
        Stage stage =(Stage) btnKembali.getScene().getWindow();
        stage.setScene(new Scene(root));
    }

}

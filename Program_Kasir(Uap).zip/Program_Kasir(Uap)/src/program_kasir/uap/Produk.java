/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package program_kasir.uap;

/**
 *
 * @author Naufal Hilal
 */
public class Produk {
    private String nama_produk;
    private double harga;
    private int jumlah;
    private double diskon;
    
    public Produk(String nama_produk,double harga,int jumlah,double diskon){
        this.diskon=diskon;
        this.harga=harga;
        this.jumlah=jumlah;
        this.nama_produk=nama_produk;
    }
    public String getNama_produk() {
        return nama_produk;
    }

    public double getHarga() {
        return harga;
    }

    public int getJumlah() {
        return jumlah;
    }

    public double getDiskon() {
        return diskon;
    }

    public void setNama_produk(String nama_produk) {
        this.nama_produk = nama_produk;
    }

    public void setHarga(double harga) {
        this.harga = harga;
    }

    public void setJumlah(int jumlah) {
        this.jumlah = jumlah;
    }

    public void setDiskon(double diskon) {
        this.diskon = diskon;
    }
    
    public void hargaDiskon(){
        
    }
}

package program_kasir.uap;

import db.DBHelper;
import java.io.IOException;
import java.sql.Connection;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.stage.Stage;

public class FormInputBarangController {

    @FXML
    private Button barangNew;

    @FXML
    private Button btnKembali_NewMakanan;

    @FXML
    private TextField fieldBarcode;

    @FXML
    private TextField fieldDiskon;

    @FXML
    private TextField fieldExpired;

    @FXML
    private TextField fieldHarga;

    @FXML
    private TextField fieldJumlah;

    @FXML
    private TextField fieldKategori;

    @FXML
    private TextField fieldNamaBarang;
    
    @FXML
    private Label lblStatus;

    @FXML
    void OpenMenu(ActionEvent event) throws IOException {
        FXMLLoader loader = new FXMLLoader(getClass().getResource("Menu.fxml"));
        Parent root =loader.load();
        
        Stage stage =(Stage) btnKembali_NewMakanan.getScene().getWindow();
        stage.setScene(new Scene(root));
    }

    @FXML
    void sendDataBarang(ActionEvent event) {
        Kategori k=new Kategori(fieldKategori.getText());
        Barang brg = new Barang(fieldBarcode.getText(),fieldExpired.getText(),fieldNamaBarang.getText(),Double.parseDouble(fieldHarga.getText()),Integer.parseInt(fieldJumlah.getText()),Double.parseDouble(fieldDiskon.getText()));
        
        BarangModel b= new BarangModel();
        b.addBarang(brg, k);
        
        if(b.status==true){
            lblStatus.setText("Berhasil Memasukan Data "+brg.getNama_produk());
        }else{
            lblStatus.setText("Gagal Memasukan Data");
        }        
        fieldBarcode.clear();
        fieldDiskon.clear();
        fieldDiskon.clear();
        fieldExpired.clear();
        fieldJumlah.clear();
        fieldHarga.clear();
        fieldJumlah.clear();
        fieldKategori.clear();
        fieldNamaBarang.clear();
    }

}

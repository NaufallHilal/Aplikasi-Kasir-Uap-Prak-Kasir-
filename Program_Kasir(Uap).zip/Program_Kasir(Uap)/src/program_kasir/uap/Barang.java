/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package program_kasir.uap;

import java.util.ArrayList;

/**
 *
 * @author Naufal Hilal
 */
public class Barang extends Produk{
    private String barcode;
    private String expired;
    private String kategori;
    private ArrayList<Kategori>kategoriList=new ArrayList<>();

    public Barang(String barcode, String expired, String nama_produk, double harga, int jumlah, double diskon) {
        super(nama_produk, harga, jumlah, diskon);
        this.barcode = barcode;
        this.expired = expired;
    }

    public String getBarcode() {
        return barcode;
    }

    public String getExpired() {
        return expired;
    }

//    public ArrayList<Kategori> getKategori() {
//        return kategori;
//    }

    public void setBarcode(String barcode) {
        this.barcode = barcode;
    }

    public void setExpired(String expired) {
        this.expired = expired;
    }

//    public void setKategori(ArrayList<Kategori> kategori) {
//        this.kategori = kategori;
//    }
//    
    public void isExpired(){
        
    }
//    public void addKategori(Kategori k){
//        kategori.add(k);
//    }
//
//    public String getkategori(){
//        String getKategori="";
//        String str=", ";
//        for(Kategori kat:kategori){
//            getKategori.concat(str).concat(kat.getNama_kategori());
//        }
//        return getKategori;
//    }
//

    public String getKategori() {
        return kategori;
    }

    public void setKategori(String kategori) {
        this.kategori = kategori;
    }
    
}
    

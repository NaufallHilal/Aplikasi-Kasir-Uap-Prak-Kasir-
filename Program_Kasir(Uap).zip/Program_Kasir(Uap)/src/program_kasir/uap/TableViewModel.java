/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package program_kasir.uap;

import static db.DBHelper.getConnection;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Statement;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;

/**
 *
 * @author Naufal Hilal
 */
public class TableViewModel {
        public ObservableList<Makanan> getMakanan(){
        ObservableList<Makanan> makananList = FXCollections.observableArrayList();
        Connection conn=getConnection();
        String query="SELECT * FROM makanan;";
        Statement st;
        ResultSet rs;
        try{
        st=conn.createStatement();
        rs=st.executeQuery(query);
        Makanan makanan;
        while(rs.next()){
            makanan=new Makanan(rs.getInt("id"),rs.getInt("daya_tahan"),rs.getString("nama_makanan"),rs.getDouble("harga"),rs.getInt("jumlah"),rs.getDouble("diskon"));
            makananList.add(makanan);
        }
        }catch(Exception ex){
           ex.printStackTrace();
        }
        return makananList;
        }
        
        public ObservableList<Barang> getBarang(){
            ObservableList<Barang> barangList=FXCollections.observableArrayList();
            Connection conn=getConnection();
            String query="SELECT * FROM barang;";
            Statement st;
            ResultSet rs;
            Barang barang;
            Kategori kategori;
            try{
                st=conn.createStatement();
                rs=st.executeQuery(query);
            while(rs.next()){
                barang=new Barang(rs.getString("barcode"),rs.getString("expired"),rs.getString("nama_barang"),rs.getDouble("harga"),rs.getInt("jumlah"),rs.getDouble("diskon"));
                barang.setKategori(rs.getString("kategori"));
                barangList.add(barang);
            }
            }catch(Exception ex){
                ex.printStackTrace();
            }
            return barangList;
        }
}

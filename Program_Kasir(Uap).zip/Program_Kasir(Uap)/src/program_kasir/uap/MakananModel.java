/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package program_kasir.uap;

import db.DBHelper;
import java.sql.Connection;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author Naufal Hilal
 */
public class MakananModel {
     private final Connection CONN;
     public boolean status;

    public MakananModel() {
        this.CONN = DBHelper.getConnection();
    } 
    
    public void addMakanan(Makanan n){
      String insert="INSERT INTO makanan VALUES ('"
                +n.getId()+"', '"+n.getNama_produk()
                +"', '"+n.getHarga()+"', '"+n.getJumlah()+"', '"+n.getDiskon()+"', '"+n.getDaya_tahan()+"');";
         try {
             if(CONN.createStatement().executeUpdate(insert)>0){
                 System.out.println("Berhasil Memasukan Data");
                 status=true;
             }else{
                 System.out.println("Gagal Memasukan Data");
                 status=false;
             }
         } catch (SQLException ex) {
             Logger.getLogger(MakananModel.class.getName()).log(Level.SEVERE, null, ex);
         }
    }
    
    public void deleteMakanan(int id){
        String delete="DELETE FROM makanan WHERE id="+id+";";
            
         try {
             if(CONN.createStatement().executeUpdate(delete)>0){
                 System.out.println("Berhasil Menghapus Data");
                 status=true;
             }else{
                 System.out.println("Gagal Menghapus Data");
                 status=false;
             }
         } catch (SQLException ex) {
             Logger.getLogger(MakananModel.class.getName()).log(Level.SEVERE, null, ex);
         }
       
    }
}
